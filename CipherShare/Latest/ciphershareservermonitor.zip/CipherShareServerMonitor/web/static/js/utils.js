// Some of the utilities here require prototype*.js to first be included.


function is_defined(x)
{
    return typeof(x) != 'undefined';
}

function is_set(x)
{
    return is_defined(x) && (x != null);
}

function is_mobile_browser()
{
    // Regex taken from: http://johannburkard.de/blog/www/mobile/simple-mobile-phone-detection.html
    return /IEMobile|Windows CE|NetFront|PlayStation|PLAYSTATION|like Mac OS X|MIDP|UP\.Browser|Symbian|Nintendo|Android/.
            test(navigator.userAgent);
}

var using_prototype = is_defined(document.observe);
var using_jquery = is_defined(window.jQuery);

var run_on_DOM_load;
if (using_prototype)
{
    run_on_DOM_load = function(funcToRun)
    {
        document.observe("dom:loaded", funcToRun);
    }
}
else if (using_jquery)
{
    run_on_DOM_load = function(funcToRun) { $(funcToRun) };
}
else
{
    // taken from http://ajaxian.com/archives/more-fun-with-domcontentloaded
    run_on_DOM_load = 
        function (funcToRun){
        (function(i) {var u =navigator.userAgent;var e=/*@cc_on!@*/false; var st =
            setTimeout;if(/webkit/i.test(u)){st(function(){var dr=document.readyState;
            if(dr=="loaded"||dr=="complete"){i()}else{st(arguments.callee,10);}},10);}
            else if((/mozilla/i.test(u)&&!/(compati)/.test(u)) || (/opera/i.test(u))){
            document.addEventListener("DOMContentLoaded",i,false); } else if(e){     (
            function(){var t=document.createElement('doc:rdy');try{t.doScroll('left');
            i();t=null;}catch(e){st(arguments.callee,0);}})();}else{window.onload=i;}})(funcToRun);}
}


function getUrlVars() 
{ 
    var map = {}; 
    var parts = window.location.search.replace(
            /[?&]+([^=&]+)(=[^&]*)?/gi, 
            function(m,key,value) 
                { map[key] = (value === undefined) ? true : value.substring(1); }); 
    return map; 
}

var makeResourceRequest;
if (using_prototype)
{
    // success_callback should take one argument, which is the response object.
    makeResourceRequest = function(request, success_callback)
    {
        makeResourceRequest.requests_outstanding += 1;
        new Ajax.Request('/resources/'+request,
                {
                  method:'GET',
                  requestHeaders: ['Accept-Encoding', 'x-gzip, gzip'],
                  onSuccess: function(transport){
                      trace("Response length:"+xhr.getResponseHeader('Content-Length') 
                              +" // Uncompressed length:"+xhr.responseText.length);
                      makeResourceRequest.requests_outstanding -= 1;
                      success_callback(transport.responseText.evalJSON(true));
                  },
                  onFailure: function(){ alert('Request to log data resource failed'); }
                });
    }
}
else if (using_jquery)
{
    makeResourceRequest = function(request, success_callback) {
        $.ajax({
            beforeSend: function(xhr) {xhr.setRequestHeader('Accept-Encoding', 'x-gzip, gzip');} 
        });
        
        makeResourceRequest.requests_outstanding += 1;
        //trace("makeResourceRequest.requests_outstanding:"+makeResourceRequest.requests_outstanding);
        
        $.getJSON(
            '/resources/' + request, 
            function(data, textStatus, xhr) {
                trace("Response length:"+xhr.getResponseHeader('Content-Length') 
                        +" // Uncompressed length:"+xhr.responseText.length);
                makeResourceRequest.requests_outstanding -= 1;
                trace("makeResourceRequest.requests_outstanding:"+makeResourceRequest.requests_outstanding);
                success_callback(jQuery.parseJSON(xhr.responseText));                
            });
    }
}
else
{
    makeResourceRequest = function(request, success_callback)
    {
        makeResourceRequest.requests_outstanding += 1;
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "/resources/"+request, false);
        xhr.setRequestHeader('Accept-Encoding', 'x-gzip, gzip');
        xhr.send(null);
        trace("Response length:"+xhr.getResponseHeader('Content-Length') 
                +" // Uncompressed length:"+xhr.responseText.length);
        success_callback(JSON.parse(xhr.responseText));
        makeResourceRequest.requests_outstanding -= 1;
    }
}
makeResourceRequest.requests_outstanding = 0;

// Adds tooltips to all page elements with a title attribute.
// (May make more flexible in the future.)
function addTooltips()
{
    // Tooltips just interfere with touch interaction on mobile browsers.
    if (!is_mobile_browser())
    {
        $('*[title]').qtip(
            {
              style: {
                tip: { corner: true },
                classes:'ui-tooltip-cluetip',
                widget: true
                },
              position: {
                at: 'top left',
                my: 'bottom left',
                adjust: {
                  screen: true
                }
              }
            });
    }
}

// Sets the lifetime of the cookies (to a far-away date).
function setCookieLifetime()
{
    // We'll make our control cookies long-lived. (The default is session.)
    var expiryDate = new Date();
    expiryDate.setFullYear(expiryDate.getFullYear()+10);
    $.cookies.setOptions({expiresAt: expiryDate});
}

// Questionably correct implementation of jQuery's and Prototype's extend.
function addDictionaryElements(dest_dict, src_dict)
{
    var _dest_dict = Object.clone(dest_dict);
    
    var src_keys = Object.keys(src_dict);
    for (var i = 0; i < src_keys.length; i++)
    {
        key = src_keys[i];
        
        if (_dest_dict[key] == null) 
        {
            _dest_dict[key] = src_dict[key];
        }
        else if (typeof src_dict[key] == typeof {})
        {
            // Assuming that _dest_dict[key] is also a dictionary.
            _dest_dict[key] = addDictionaryElements(_dest_dict[key], src_dict[key]);
        }
        else // scalar -- src_dict wins
        {
            _dest_dict[key] = src_dict[key];
        }
    }
    
    return _dest_dict;
}

/*
 * Number formattting
 */

// Formats number into human readable form. (i.e., puts thousands-separator commas).
// From: http://snipplr.com/view/5945/javascript-numberformat--ported-from-php/
function formatNumber( number, decimals, dec_point, thousands_sep ) 
{
    // http://kevin.vanzonneveld.net
    // + original by: Jonas Raoni Soares Silva (http://www.jsfromhell.com)
    // + improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // + bugfix by: Michael White (http://crestidg.com)
    // + bugfix by: Benjamin Lupton
    // + bugfix by: Allan Jensen (http://www.winternet.no)
    // + revised by: Jonas Raoni Soares Silva (http://www.jsfromhell.com)
    // * example 1: number_format(1234.5678, 2, '.', '');
    // * returns 1: 1234.57
    
    var n = number, c = isNaN(decimals = Math.abs(decimals)) ? 2 : decimals;
    var d = dec_point == undefined ? "." : dec_point;
    var t = thousands_sep == undefined ? "," : thousands_sep, s = n < 0 ? "-" : "";
    var i = parseInt(n = Math.abs(+n || 0).toFixed(c)) + "", j = (j = i.length) > 3 ? j % 3 : 0;
     
    return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
}

// Formats byte numbers to be human-readable. 
// From: http://snipplr.com/view/5949/format-humanize-file-byte-size-presentation-in-javascript/
function formatByteSize(bytes) 
{
    var formatted = "";
    if (bytes >= 1073741824) 
        formatted = formatNumber(bytes / 1073741824, 2, '.', '') + ' GB';
    else if (bytes >= 1048576)
        formatted = formatNumber(bytes / 1048576, 2, '.', '') + ' MB';
    else if (bytes >= 1024)
        formatted = formatNumber(bytes / 1024, 0) + ' KB';
    else
        formatted = formatNumber(bytes, 0) + ' B';

    return formatted;
}

/*
 * Logging helpers
 */

// If Firebug or Firebug-Lite is present, we'll use that for logging. Otherwise
// we'll use a hack way. (Or shut off loggging completely.)
// This is an ugly but effective way of logging an error to the browser console. 
function cheapLog(str)
{
    setTimeout("cheapLog_helper('"+str+"')", 1)
}
function cheapLog_helper(str)
{
    throw new Error("DEBUG: "+str)
}

var trace = function (log_txt) {
    if (is_set(window.console)) 
    {
        console.log(log_txt);
    }
    else
    {
        //cheapLog(log_txt);
    }
}



