/*
 * 
 */

// Converts fresh-from-JSON results into google.visualization.DataTable object,
// which can then be given to a Google Data Visualization graph.
// If the results have a linear_regression member, it will be included.
// results: may be the results directly, or may be an object with a results member.
// column_info: [{results_field_name:xxx, data_type:yyy, display_name:zzz, exclude(optional):true},...]
//      Where data_type is one of 'string' 'number' 'boolean' 'date' 'datetime' 'timeofday'
//      The first column will be the x-axis.
//
// Return value is an object: 
// { gdata: the Google visualization data,
//   summary:
//      overall: { row_count: n, sum: n }
//      columns: object with keyed by column names -- e.g.:
//          'column-blah': { sum: n } 
// }
// Sums will not be valid if column values are not numeric.
// 
// NOTE: for right now, linear_regression stuff isn't output 
function convertResultsToGviz(results, column_info)
{
    var linear_regression = null;
    if (is_defined(results['linear_regression']))
        linear_regression = results['linear_regression'];
    
    if (is_defined(results['results']))
        results = results['results'];
    
    var output = {
            gdata: new google.visualization.DataTable(),
            summary: {
                overall: { row_count: 0, sum: 0},
                columns: {}
            }
    };
    
    $.each(column_info, function(key, column) {
        if (is_defined(column.exclude) && column.exclude) return;
        output.gdata.addColumn(column.data_type, column.display_name);
        output.summary.columns[column.results_field_name] = { sum: 0 };
    });
    
    // We're going to use nested maps to add all of our rows at once -- a huge
    // array of number-of-columns arrays.
    output.gdata.addRows(
            $.map(results, function(result, result_index) { // loop through the rows
                output.summary.overall.row_count += 1;
                // The other map will flatten out the array returned by the inner
                // map (see jQuery documentation), so we'll put that into another
                // array that will instead be discarded.
                return Array($.map(column_info, function(column, column_index) { // loop through the columns in the row
                    if (is_defined(column.exclude) && column.exclude) return null;
                    var value = result[column.results_field_name];
                    if (column.data_type == 'date')
                    {
                        return new Date().setISO8601(value);
                    }
                    else
                    {
                        if (typeof(value) == 'number')
                        {
                            output.summary.overall.sum += value;
                            output.summary.columns[column.results_field_name].sum += value;
                        }
                        return value;
                    }
                }));
            })
        );
    
    return output;
}

// Dygraphs has a bug-ish quirk where it assigns a default width and
// height to the graph. We need to clear them.
function setCorrectGraphSize(graphDiv) 
{
    $(graphDiv).width('');
    $(graphDiv).height('');
    
    // Note that if resize() is called before the graphs are visible (which can
    // happen with the subgraphs), then the Dygraphs code will crash.
    if (graphDiv.offsetWidth
        && is_set($(graphDiv).data('graph')))
    {
        $(graphDiv).data('graph').resize();
    }
}

/*
 * Linear Regression stuff
 */

function calculateRegressionPoint(xvalue, setname, linear_regression)
{
    var value = 0.0;
    var exponent = 0;
    for (var i = linear_regression[setname].length-1; i >= 0; i--)
    {
        value += linear_regression[setname][i] * Math.pow(xvalue, exponent);
        exponent += 1;
    }
    
    return value;
}

/* Linear Least Squares Regression 
 * Probably not terribly efficient
 * From here: http://dracoblue.net/dev/linear-least-squares-in-javascript/159/
 */
function findLineByLeastSquares(values_x, values_y) 
{
    var sum_x = 0;
    var sum_y = 0;
    var sum_xy = 0;
    var sum_xx = 0;
    var count = 0;

    /*
    * We'll use those variables for faster read/write access.
    */
    var x = 0;
    var y = 0;
    var values_length = values_x.length;

    if (values_length != values_y.length) {
    throw new Error('The parameters values_x and values_y need to have same size!');
    }

    /*
    * Nothing to do.
    */
    if (values_length === 0) {
    return [ [], [] ];
    }

    /*
    * Calculate the sum for each of the parts necessary.
    */
    for (var v = 0; v < values_length; v++) {
    x = values_x[v];
    y = values_y[v];
    sum_x += x;
    sum_y += y;
    sum_xx += x*x;
    sum_xy += x*y;
    count++;
    }

    /*
    * Calculate m and b for the formular:
    * y = x * m + b
    */
    var m = (count*sum_xy - sum_x*sum_y) / (count*sum_xx - sum_x*sum_x);
    var b = (sum_y/count) - (m*sum_x)/count;

    /*
    * We will make the x and y result line now
    */
    var result_values_x = [];
    var result_values_y = [];

    for (var v = 0; v < values_length; v++) {
    x = values_x[v];
    y = x * m + b;
    result_values_x.push(x);
    result_values_y.push(y);
    }

    return [result_values_x, result_values_y];
}

// The equation is:
//      y = a*x + b
// So we'll solve like this:
//      x = (y - b) / a
// NOTE: May return negative number.
function solveLinearRegressionForX(y, a, b)
{
    return (y - b) / a;
}
