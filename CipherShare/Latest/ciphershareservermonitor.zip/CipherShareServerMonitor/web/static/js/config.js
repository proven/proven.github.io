var config = {};

config.WARNING_COLOR = 'red';
config.WEEKS_UNTIL_EXHAUSION_WARNING = 12
