if (window['google'] != undefined && window['google']['loader'] != undefined) {
if (!window['google']['visualization']) {
window['google']['visualization'] = {};
google.visualization.Version = '1.0';
google.visualization.JSHash = 'efdb9398400374ac755c95e00e6250bc';
google.visualization.LoadArgs = 'file\75visualization\46v\0751\46packages\75linechart';
}
google.loader.writeLoadTag("script", google.loader.ServiceBase + "/api/visualization/1.0/efdb9398400374ac755c95e00e6250bc/default,browserchart,linechart.I.js", false);
}
